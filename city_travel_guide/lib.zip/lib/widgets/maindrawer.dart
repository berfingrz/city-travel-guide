import 'package:flutter/material.dart';

bool isSwitched = true;

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        DrawerHeader(
            decoration: BoxDecoration(
                gradient: LinearGradient(colors: <Color>[
              Colors.deepPurple,
              Colors.deepPurpleAccent
            ])),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Material(
                    borderRadius: BorderRadius.all(Radius.circular(50)),
                    elevation: 10,
                    child: Container(
                      width: 60,
                      height: 60,
                      child: CircleAvatar(
                        backgroundImage: AssetImage('images/cascade.png'),
                        backgroundColor: Colors.blue,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Text(
                    "Cascade",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  ),
                  SizedBox(
                    height: 3,
                  ),
                  Text(
                    "Team 6",
                    style: TextStyle(
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w300),
                  ),
                ],
              ),
            )),
        SizedBox(
          height: 20.0,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Aybüke Bilgesu Güner"),
          subtitle: Text("1700004320"),
          dense: true,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Aziz Can Sağlam"),
          subtitle: Text("1700001589"),
          dense: true,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Berfin Gürz"),
          subtitle: Text("1700002907"),
          dense: true,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Kerem Yavuz"),
          subtitle: Text("1700002885"),
          dense: true,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Oğuzalp Tellioğlu"),
          subtitle: Text("1700003505"),
          dense: true,
        ),
        ListTile(
          onTap: () {},
          leading: Icon(
            Icons.person,
          ),
          title: Text("Oğuz Kadir Vatansever"),
          subtitle: Text("1700004342"),
          dense: true,
        ),
        Container(
            child: Align(
                alignment: FractionalOffset.bottomCenter,
                child: Column(
                  children: <Widget>[
                    Divider(),
                    ListTile(
                      leading: Icon(Icons.settings),
                      title: Text('Settings'),
                      onTap: () {},
                    ),
                    ListTile(
                      leading: Icon(Icons.nightlight_round),
                      title: Text('Dark Mode'),
                      trailing: Switch(
                        value: isSwitched,
                        onChanged: (value) {},
                        activeTrackColor: Colors.deepPurpleAccent,
                        activeColor: Colors.deepPurpleAccent[700],
                      ),
                    ),
                  ],
                ))),
      ],
    );
  }
}
