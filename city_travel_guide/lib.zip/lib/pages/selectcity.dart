import 'package:city_travel_guide/data/database_helper.dart';
import 'package:city_travel_guide/pages/cityinfo.dart';
import 'package:city_travel_guide/widgets/maindrawer.dart';
import 'package:flutter/material.dart';

class SelectCity extends StatefulWidget {
  @override
  _SelectCity createState() => _SelectCity();
}

class _SelectCity extends State<SelectCity> {
  final dbHelper = DbHelper();

  @override
  void initState() {
    dbHelper.initDb();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Select a City',
          style: Theme.of(context).primaryTextTheme.headline6,
        ),
        actions: <Widget>[
          IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CityScreen()),
                );
              }),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      drawer: Drawer(child: MainDrawer()),
    );
  }
}
