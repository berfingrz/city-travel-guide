import 'package:flutter/material.dart';

class CategoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DefaultTabController(
          length: 2,
          child: NestedScrollView(
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return [
                  SliverAppBar(
                    expandedHeight: 200.0,
                    floating: false,
                    pinned: true,
                    flexibleSpace: FlexibleSpaceBar(
                        centerTitle: true,
                        title: Text("What are you looking for?",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                            )),
                        background: Image.network(
                          "https://imagessl.etstur.com/files/images/cruise/660_330/24-kas.jpg",
                          fit: BoxFit.cover,
                        )),
                    actions: <Widget>[
                      IconButton(icon: Icon(Icons.search), onPressed: () {
                        
                      }),
                      IconButton(icon: Icon(Icons.more_vert), onPressed: () {})
                    ],
                  ),
                ];
              },
              body: Column(
                children: <Widget>[
                  Card(
                      margin: EdgeInsets.only(top: 20, left: 10, right: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const ListTile(
                            leading: Icon(Icons.info),
                            title: Text("Some information again."),
                            subtitle: Text('What can user do?'),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              TextButton(
                                onPressed: () {},
                                child: Text("Navigation"),
                              ),
                              const SizedBox(width: 8),
                            ],
                          ),
                        ],
                      )),
                  Expanded(
                      child: ListView(
                    children: [
                      ListTile(
                        onTap: () {},
                        leading: Icon(Icons.place),
                        title: Text("Historical Places"),
                        subtitle: Text("Info..."),
                        dense: true,
                      ),
                      ListTile(
                        onTap: () {},
                        leading: Icon(Icons.airplanemode_active_outlined),
                        title: Text("Transportation"),
                        subtitle: Text("Info..."),
                        dense: true,
                      ),
                      ListTile(
                        onTap: () {},
                        leading: Icon(Icons.grade_rounded),
                        title: Text("Parks"),
                        subtitle: Text("Info..."),
                        dense: true,
                      ),
                      ListTile(
                        onTap: () {},
                        leading: Icon(
                          Icons.restaurant,
                        ),
                        title: Text("Restaurants"),
                        subtitle: Text("Info..."),
                        dense: true,
                      ),
                      ListTile(
                        onTap: () {},
                        leading: Icon(
                          Icons.shopping_bag,
                        ),
                        title: Text("Shopping malls"),
                        subtitle: Text("Info..."),
                        dense: true,
                      ),
                    ],
                  ))
                ],
              )),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {},
          child: const Icon(Icons.favorite_outline),
          backgroundColor: Colors.deepPurple,
        ));
  }
}
