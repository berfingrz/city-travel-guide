import 'package:flutter/material.dart';
import 'category.dart';

class CityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DefaultTabController(
          length: 2,
          child: NestedScrollView(
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return [
                  SliverAppBar(
                    expandedHeight: 200.0,
                    floating: false,
                    pinned: true,
                    flexibleSpace: FlexibleSpaceBar(
                        centerTitle: true,
                        title: Text("City Name",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                            )),
                        background: Image.network(
                          "https://www.bizevdeyokuz.com/wp-content/uploads/antalya-gezilecek-yerler-1.jpg",
                          fit: BoxFit.cover,
                        )),
                    actions: <Widget>[
                      IconButton(icon: Icon(Icons.search), onPressed: () {}),
                      IconButton(icon: Icon(Icons.more_vert), onPressed: () {})
                    ],
                  ),
                ];
              },
              body: Column(
                children: <Widget>[
                  Card(
                      margin: EdgeInsets.only(top: 20, left: 10, right: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const ListTile(
                            leading: Icon(Icons.info),
                            title: Text("Some information about city."),
                            subtitle: Text(
                                'Text about the location, history, and culture.'),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              TextButton(
                                onPressed: () {},
                                child: Text("Navigation"),
                              ),
                              const SizedBox(width: 8),
                            ],
                          ),
                        ],
                      )),
                  Expanded(
                      child: ListView.separated(
                          separatorBuilder: (context, index) => Divider(
                                color: Colors.black,
                              ),
                          itemCount: 5,
                          itemBuilder: (BuildContext context, int index) {
                            return ListTile(
                              title: Text("County Name"),
                              subtitle: Text("City, Country "),
                              leading: CircleAvatar(
                                backgroundColor: Colors.purpleAccent,
                              ),
                              trailing: Icon(Icons.keyboard_arrow_right),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CategoryScreen()),
                                );
                              },
                            );
                          }))
                ],
              )),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {},
          child: const Icon(Icons.favorite_outline),
          backgroundColor: Colors.deepPurple,
        ));
  }
}
